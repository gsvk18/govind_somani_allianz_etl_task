import pytest
from src.utils import calculate_summary

def test_calculate_summary():
    data = [
        {'year': 1990, 'team': 'A', 'wins': 30},
        {'year': 1990, 'team': 'B', 'wins': 20},
        {'year': 1990, 'team': 'C', 'wins': 10},
        {'year': 1991, 'team': 'D', 'wins': 15},
        {'year': 1991, 'team': 'E', 'wins': 25},
        {'year': 1991, 'team': 'F', 'wins': 5}
    ]

    summary = calculate_summary(data)
    assert summary[1990][0]['team'] == 'A'
    assert summary[1990][1]['team'] == 'C'
    assert summary[1991][0]['team'] == 'E'
    assert summary[1991][1]['team'] == 'F'
