import aiohttp
import asyncio
import zipfile
from bs4 import BeautifulSoup
from typing import List, Dict
import xlsxwriter
import os

BASE_URL = 'https://www.scrapethissite.com/pages/forms/?page_num='


async def fetch(session, url):
    async with session.get(url, ssl=False) as response:
        return await response.text()


async def fetch_all_pages(base_url: str, total_pages: int) -> List[str]:
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as session:
        tasks = [fetch(session, f"{base_url}{i}") for i in range(1, total_pages + 1)]
        return await asyncio.gather(*tasks)


def parse_page(html: str) -> List[Dict]:
    soup = BeautifulSoup(html, 'html.parser')
    table = soup.find('table', {'class': 'table'})
    if table is None:
        # Save the HTML for debugging
        with open('debug.html', 'w') as file:
            file.write(html)
        raise ValueError("Table with class 'table' not found in the HTML content.")

    rows = table.find_all('tr')[1:]

    data = []
    for row in rows:
        cols = row.find_all('td')
        if len(cols) < 9:
            continue
        data.append({
            'team': cols[0].text.strip(),
            'year': int(cols[1].text.strip()),
            'wins': int(cols[2].text.strip()),
            'losses': int(cols[3].text.strip()),
            'ot_losses': int(cols[4].text.strip()) if cols[4].text.strip() else 0,
            'goals_for': int(cols[6].text.strip()),
            'goals_against': int(cols[7].text.strip()),
            'diff': int(cols[8].text.strip())
        })
    return data


def save_html_files(html_pages: List[str], output_dir: str):
    os.makedirs(output_dir, exist_ok=True)
    for idx, html in enumerate(html_pages, 1):
        with open(f"{output_dir}/{idx}.html", 'w') as file:
            file.write(html)


def create_zip_file(input_dir: str, zip_filename: str):
    with zipfile.ZipFile(zip_filename, 'w') as zipf:
        for foldername, subfolders, filenames in os.walk(input_dir):
            for filename in filenames:
                file_path = os.path.join(foldername, filename)
                zipf.write(file_path, os.path.basename(file_path))


def create_excel_file(data: List[Dict], excel_filename: str):
    workbook = xlsxwriter.Workbook(excel_filename)
    sheet1 = workbook.add_worksheet("NHL Stats 1990-2011")
    sheet2 = workbook.add_worksheet("Winner and Loser per Year")

    headers = ['Year', 'Team', 'Wins', 'Losses', 'OT Losses', 'Goals For', 'Goals Against', 'Diff']
    for col_num, header in enumerate(headers):
        sheet1.write(0, col_num, header)

    for row_num, entry in enumerate(data, 1):
        sheet1.write(row_num, 0, entry['year'])
        sheet1.write(row_num, 1, entry['team'])
        sheet1.write(row_num, 2, entry['wins'])
        sheet1.write(row_num, 3, entry['losses'])
        sheet1.write(row_num, 4, entry['ot_losses'])
        sheet1.write(row_num, 5, entry['goals_for'])
        sheet1.write(row_num, 6, entry['goals_against'])
        sheet1.write(row_num, 7, entry['diff'])

    yearly_data = {}
    for entry in data:
        year = entry['year']
        if year not in yearly_data:
            yearly_data[year] = []
        yearly_data[year].append(entry)

    summary_headers = ['Year', 'Winner', 'Winner Num. of Wins', 'Loser', 'Loser Num. of Wins']
    for col_num, header in enumerate(summary_headers):
        sheet2.write(0, col_num, header)

    row_num = 1
    for year, entries in yearly_data.items():
        sorted_entries = sorted(entries, key=lambda x: x['wins'])
        winner = sorted_entries[-1]
        loser = sorted_entries[0]
        sheet2.write(row_num, 0, year)
        sheet2.write(row_num, 1, winner['team'])
        sheet2.write(row_num, 2, winner['wins'])
        sheet2.write(row_num, 3, loser['team'])
        sheet2.write(row_num, 4, loser['wins'])
        row_num += 1

    workbook.close()


async def main():
    total_pages = 24
    html_pages = await fetch_all_pages(BASE_URL, total_pages)

    save_html_files(html_pages, 'html_pages')
    create_zip_file('html_pages', 'html_pages.zip')

    all_data = []
    for html in html_pages:
        all_data.extend(parse_page(html))

    create_excel_file(all_data, 'hockey_stats.xlsx')


if __name__ == '__main__':
    asyncio.run(main())
