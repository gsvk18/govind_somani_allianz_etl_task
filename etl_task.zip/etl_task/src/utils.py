from typing import List, Dict, Tuple

def calculate_summary(data: List[Dict]) -> Dict[int, Tuple[Dict, Dict]]:
    yearly_summary = {}
    for entry in data:
        year = entry['year']
        if year not in yearly_summary:
            yearly_summary[year] = []
        yearly_summary[year].append(entry)

    result = {}
    for year, entries in yearly_summary.items():
        sorted_entries = sorted(entries, key=lambda x: x['wins'])
        result[year] = (sorted_entries[-1], sorted_entries[0])

    return result
