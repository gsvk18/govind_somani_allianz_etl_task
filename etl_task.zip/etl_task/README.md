# ETL Task

## Description

This project scrapes hockey team stats from [Scrape This Site](https://www.scrapethissite.com/pages/forms/), processes the data, and outputs the results in a ZIP file of HTML pages and an Excel workbook with detailed statistics.

## Requirements

- Python 3.7+
- aiohttp
- BeautifulSoup4
- xlsxwriter
- pytest

## Installation

1. Clone the repository:
    ```bash
    git clone <repository-url>
    ```

2. Navigate to the project directory:
    ```bash
    cd etl_task
    ```

3. Install the dependencies:
    ```bash
    pip install -r requirements.txt
    ```

## Usage

To run the ETL pipeline, execute the following command:
```bash
python src/etl.py
```

## Running Tests

To run the tests, execute:
```bash
pytest
```

## Output

- `html_pages.zip`: A ZIP file containing the HTML pages scraped from the website.
- `hockey_stats.xlsx`: An Excel file with two sheets:
  - "NHL Stats 1990-2011": Raw scraped data.
  - "Winner and Loser per Year": Summary of the teams with the most and least wins per year.
